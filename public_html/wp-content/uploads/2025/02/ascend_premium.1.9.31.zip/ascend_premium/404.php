<?php 
/*
* 404
*/
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
    get_header(); 

    /**
    * @hooked ascend_page_title - 20
    */
     do_action('kadence_page_title_container');
    ?>
    <div id="content" class="container">
      	<div class="row">
          	<div class="main <?php echo esc_attr(ascend_main_class()); ?>" id="ktmain" role="main">
                <div class="kt-404-alert entry-content">
                    <h3><?php _e('Sorry, but the page you were trying to view does not exist.', 'ascend'); ?></h2>

	                <p><?php _e('It looks like this was the result of either a mistyped address or an out-of-date link', 'ascend'); ?></p>
	      			<?php get_search_form(); ?>
      			</div>
      		</div><!-- /.main -->
       		<?php
				/**
			    * Sidebar
			    */
				if (ascend_display_sidebar()) : 
				      	get_sidebar();
			    endif; ?>
    	</div><!-- /.row-->
    </div><!-- /.content -->
    <?php 
    /**
    * Footer
    */
	get_footer(); ?>