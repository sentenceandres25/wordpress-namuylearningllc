function ascend_kadence_blocks_prebuilt( options ) {
	var blockOptions = [
		{
			key: 'ascend_prebuilt_simple_contact',
			content: "<!-- wp:kadence/rowlayout {\"uniqueID\":\"_2c3311-d1\",\"columnGutter\":\"wider\",\"colLayout\":\"equal\",\"verticalAlignment\":\"middle\",\"firstColumnWidth\":35,\"secondColumnWidth\":65} -->\n<div class=\"wp-block-kadence-rowlayout alignnone\"><div id=\"kt-layout-id_2c3311-d1\" class=\"kt-row-layout-inner  kt-layout-id_2c3311-d1\"><div class=\"kt-row-column-wrap kt-has-2-columns kt-gutter-wider kt-row-valign-middle kt-row-layout-equal kt-tab-layout-inherit kt-m-colapse-left-to-right kt-mobile-layout-row kt-custom-first-width-35\"><!-- wp:kadence/column {\"uniqueID\":\"_4acaa1-b7\"} -->\n<div class=\"wp-block-kadence-column inner-column-1 kadence-column_4acaa1-b7\"><div class=\"kt-inside-inner-col\"><!-- wp:kadence/advancedheading {\"uniqueID\":\"_1d69e7-be\",\"align\":\"right\",\"size\":14,\"typography\":\"Montserrat\",\"googleFont\":true,\"fontSubset\":\"latin\",\"fontVariant\":\"800\",\"fontWeight\":\"800\"} -->\n<h2 id=\"kt-adv-heading_1d69e7-be\" class=\"kt-adv-heading_1d69e7-be wp-block-kadence-advancedheading\" style=\"text-align:right\">THOUGHTS, HOPES, DREAMS</h2>\n<!-- /wp:kadence/advancedheading -->\n\n<!-- wp:kadence/advancedheading {\"uniqueID\":\"_d25f0c-c5\",\"align\":\"right\",\"size\":50,\"lineHeight\":54,\"typography\":\"Montserrat\",\"googleFont\":true,\"fontSubset\":\"latin\",\"fontVariant\":\"200\",\"fontWeight\":\"200\"} -->\n<h2 id=\"kt-adv-heading_d25f0c-c5\" class=\"kt-adv-heading_d25f0c-c5 wp-block-kadence-advancedheading\" style=\"text-align:right\">Share with us<br/>all the great<br/>things you<br/>have to say.</h2>\n<!-- /wp:kadence/advancedheading --></div></div>\n<!-- /wp:kadence/column -->\n\n<!-- wp:kadence/column {\"id\":2,\"uniqueID\":\"_e9f343-0f\"} -->\n<div class=\"wp-block-kadence-column inner-column-2 kadence-column_e9f343-0f\"><div class=\"kt-inside-inner-col\"><!-- wp:shortcode -->\n[kt_contact_form style=\"light\" enable_math=\"false\"]\n<!-- /wp:shortcode --></div></div>\n<!-- /wp:kadence/column --></div></div></div>\n<!-- /wp:kadence/rowlayout -->", 
			name: wp.i18n.__( 'Simple Contact' ),
			background: 'light',
			category: [ 'ascend' ],
			keywords: [ wp.i18n.__( 'Contact' ), wp.i18n.__( 'Ascend' ) ],
			image: 'https://s3.amazonaws.com/ktdemocontent/layouts/snip_contact_beside_title-min.jpg',
		},
	];
	var newOptions = options.concat( blockOptions );
	//console.log(newOptions);
	return newOptions;
}
wp.hooks.addFilter( 'kadence.prebuilt_array', 'ascend_premium/prebuilt', ascend_kadence_blocks_prebuilt );