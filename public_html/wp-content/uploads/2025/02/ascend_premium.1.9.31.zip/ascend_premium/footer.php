<?php
/*
- Force plugins to stop stating incorrect errors -
wp_footer();
*/
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
			/**
			 *
			 * @hooked ascend_above_footer_widget_output - 20
			 */
			do_action( 'ascend_after_content' ); ?>
			</div><!-- /.wrap -->
			<?php
			do_action( 'ascend_footer' );
			?>
		</div><!--Wrapper-->
		<?php wp_footer(); ?>
	</body>
</html>
