
 Thank you for purchasing Ascend Premium Theme!

-------------------------------------------------------
    Ascend Theme Licensing:
-------------------------------------------------------

Licensed under the General Public License V3

-------------------------------------------------------
    Frequently Asked Questions:
-------------------------------------------------------

= Where do I report security bugs found in this theme? =

Please report security bugs found in the source code of the
Ascend Premium Theme through the Patchstack
Vulnerability Disclosure Program https://patchstack.com/database/vdp/ascend_premium. The
Patchstack team will assist you with verification, CVE assignment, and
notify the developers of this theme.

-------------------------------------------------------
    Security Policy:
-------------------------------------------------------

= Reporting Security Bugs =

Please report security bugs found in the
Ascend Premium theme's source code through the
Patchstack Vulnerability Disclosure
Program https://patchstack.com/database/vdp/ascend_premium. The Patchstack team will
assist you with verification, CVE assignment, and notify the
developers of this theme.

-------------------------------------------------------
    Changelog:
-------------------------------------------------------

= Theme Name: Ascend Premium =

= Version 1.9.31 | 18th December 2024 =
* Update: WC template notice.
 * Fix: Issue with text domain loading.

= Version 1.9.30 | 25th July 2024 =
* Update: WC template notice.
* Fix: PHP 8.2 notices.

= Version 1.9.29 | 23rd May 2024 =
* Update: WC template notice.
* Update: X formerly twitter icon.
* Fix: PHP 8.2 notices.

= Version 1.9.28 | 26th September 2023 =
* Update: WC template notice.
* Fix: Issue with button sizes not rendering correctly.

= Version 1.9.27 | 15th June 2023 =
* Update: WC template notice.

= Version 1.9.26 | 9th June 2023 =
 * Fix: Possible issue with PHP 8+ and smaller featured images.

= Version 1.9.25 | 14th November 2022 =
 * Fix: File name in CMB2.

= Version 1.9.24 | 11th November 2022 =
* Update: Tweak header widget area css.
* Update: php 8.1 deprecations.
* Update: WC template notice.
* Fix: Lightbox conflict with block gallery.

= Version 1.9.23 | 18th March 2022 =
* Fix: Issue with topbar icons.

= Version 1.9.22 | 17th January 2022 =
* Update: Woocommerce template notice.
* Update: CMB

= Version 1.9.21 | 27th December 2021 =
* Fix: Keyboard navigation highlights.
* Fix: PHP notice with PHP 8.

= Version 1.9.20 | 17th August 2021 =
* Fix: Issue with shortcode rendering in some excerpts.
* Fix: Small CSS issue with woocommerce forgot password.
* Fix: Issue with nav override.

= Version 1.9.19 | 27th January 2021 =
* Fix: Issue with missing font options.
* Fix: Translation issue in search results.
* Fix: Issue with Shortcodes generator parameters show as "undefined".

= Version 1.9.18 | 5th January 2021 =
* Fix: Issue with Facet Shortcode.

= Version 1.9.17 | 5th January 2021 =
* Fix: Possible PHP notice.
* Fix: Possible Sticky Header issue.

= Version 1.9.16 | 7th December 2020 =
* Update: Theme Updater
* Update: remove wp_make_content_images_responsive from site origin text widget.
* Update: Add support for fifu.
* Update: WooCommerce template notice.
* Update: Prevent loading slick if there is not enough images.

= Version 1.9.15 | 13th August 2020 =
* Update: Issue with shortcode gen.
* Update: Admin JS.

= Version 1.9.14 | 8th August 2020 =
* Update: Hopefully prevent any issue with menus from another plugin.
* UPdate: JS for Gallery.

= Version 1.9.13 | 6th August 2020 =
* Fix: Beaver themer intergration.
* Fix: Mobile navigation menu items active/hover fonts.
* Fix: Shop page showing for the breadcrumbs.(need to be able to turn off.)
* Fix: navigation filter.
* Fix: start issue with woocommerce blocks.

= Version 1.9.12 | 20th June 2020 =
* Update: Hide API key when activated.
* Add: Beaver Themer support.
* Add: Spotify to social widget.
* Update: google font choice.
* Update: CSS tweak for paragraphs

= Version 1.9.11 | 19th May 2020 =
* Fix: Issue with product lightbox.

= Version 1.9.10 | 12th May 2020 =
* Add: Admin filter to portfolio for portfolio type.
* Add: Function to check for elementor stretch.
* Fix: Product lightbox issue.
* Fix: rel="noopener" in some Social Links.
* Fix: Video Embed issue.

= Version 1.9.9 | 28th January 2020 =
* Fix: Single Product sidebar ID issue.
* Fix: Filter slug not matching with class.

= Version 1.9.8 | 22nd January 2020 =
* Fix: Styling issue with elementor nav widget.
* Fix: Out of date template notice.
* Fix: Gutenberg Styling issue.
* Remove: data-vocabulary.org from breadcrumbs.

= Version 1.9.7 | 14th January 2020 =
* Add: option to have background colors effect Gutenberg editor.
* Fix: Sidebar ID issue on product page.

= Version 1.9.6 | 13th January 2020 =
* Add: Allow typed text 6 lines.
* Fix: Sidebar issue on product page.

= Version 1.9.5 | 8th January 2020 =
* Fix: Bug with two search icons in the topbar.
* Fix: Bug with Portfolio lightbox showing when it shouldn't.
* Fix: Bug in woocommerce archive with list results.

= Version 1.9.4 | 2nd January 2020 =
* Fix: Issue with posts page not inheriting blog page template sidebar settings.
* Update: Sidebar Logic
* Update: Widget CSS
* Update: Add option to turn off icon font.

= Version 1.9.3 | 4th December 2019 =
* Add: Pagination for the home portfolio output.
* Update: FacetWP integration.
* Update: Comment template.
* Update: Scripts, optimize when some scripts load.
* Update: analytics, move anonymizeIp
* Add: Within group navigation option for staff.
* Fix: Small css bug on home page.

= Version 1.9.2 | 20th November 2019 =
* Fix: PHP7.1 bug with custom post type. 

= Version 1.9.1 | 18th November 2019 =
* Fix: Similar posts not working.

= Version 1.9.0 | 15th November 2019 =
* Update: Product Brands use product archive sidebar.
* Add: Filter for portfolio post default.
* Fix: CSS for post carousel. 

= Version 1.8.9 | 10th October 2019 =
* Update: Change cart to prevent issue with Elementor.

= Version 1.8.8 | 9th October 2019 =
* Update: Refactor code.
* Update: Change Video Post Schema.

= Version 1.8.7 | 27th September 2019 =
* Update: Issue with people using WordPress 5.1.2

= Version 1.8.6 | 26th September 2019 =
* Fix: Bug with some styling.

= Version 1.8.5 | 25th September 2019 =
* Update: Elementor Pro Individual Header and Footer Support.
* Update: CSS for portfolio navigation.
* Fix: Title in post issue.
* Update: CSS loading.
* Update: Lifter LMS Support.

= Version 1.8.4 | 19th September 2019 =
* Update: Breadcrumbs, new class better rank math support.
* Update: Main term, supports rank math.
* Add: Option to show Modified Date instead of Publish Date.

= Version 1.8.3 | 7th August 2019 =
* Fix: Gallery Block Lightbox.
* Update: WC 3.7 ready.
* Fix: Chrome Warning for Smooth Scroll.

= Version 1.8.2 | 12th July 2019 =
* Fix: Sidebar issue.

= Version 1.8.1 | 11th July 2019 =
* Update: Better tribe support.
* Update: Better testimonial email output.
* Update: Tweak safari css bug.
* Update: Bug with Fullwidth images.
* Update: Lifter LMS Support.

= Version 1.8.0 | 29th April 2019 =
* Update: PHP 5.6 issue with license activation.

= Version 1.7.9 | 15th April 2019 =
* Update: Author Box Date output.
* Fix: Syntax error.

= Version 1.7.8 | 10th April 2019 =
* Update: WC 3.6.0 support.
* Update: Tweek font size for page titles.

= Version 1.7.7 | 3rd April 2019 =
* Update: Add Dismiss to notice for missing API.
* Update: Typo.
* Update: Small CSS change.

= Version 1.7.6 | 29th March 2019 =
* Update: Fix enable math in testimonial form.

= Version 1.7.5 | 21th March 2019 =
* Update: Change Blocks Notify

= Version 1.7.4 | 20th March 2019 =
* Update: 404 Page ID string translatable.
* Update: Change Blocks Notify
* Update: Option to set topbar account login link.
* Update: Infinite scroll issue.

= Version 1.7.3 | 20th February 2019 =
* Update: 404 Page ID string translatable.
* Update: Change the font color in Gutenberg Editor.
* Update: Tabs css tweek.
* Update: Woocommerce 3.5.5 support.

= Version 1.7.2 | 30th January 2019 =
* Update: Testimonial Form intergrate with Google Re
* Update: Splitcontent tablet issue.
* Update: Add gallery-custom-links Support.
* Fix: Brizy Lightbox issue.
* Fix: Two blog templates showing.
* Update: CMB2
* Add: Better FacetWP support.
* Add: Child Theme creator (Props @mgibbs189)
* Add: Check for Kadence Blocks.
* Add: Prebuilt Content to Kadence Blocks.
* Update: Remove Schema from Post loop.

= Version 1.7.1 | 21st January 2019 =
* Update: Contact Form intergrate with Google Re

= Version 1.7.0 | 8th January 2019 =
* Update: Slider Bug fix.

= Version 1.6.9 | 8th January 2019 =
* Update: Woo plugin conflict.
* Fix: Social Widget title bug.
* Fix: Testimonial Carousel Shortcode.

= Version 1.6.8 | 3rd December 2018 =
* Update: Add ascend_post_layout_args_array filter
* Update: Better support for WordPress 5
* Add: Reddit to Social Widget.

= Version 1.6.7 | 23rd November 2018 =
* Update: Tabs ID.
* Update: Add Kadence Blocks Pro to bundled.
* UPdate: Parallax filter.

= Version 1.6.6 | 30th October 2018 =
* Update: Woocommerce notice.
* Update: Gutenberg CSS tweek.

= Version 1.6.5 | 24th October 2018 =
* Update: Woocommerce notice.

= Version 1.6.4 | 9th October 2018 =
* Update: Tweek schema.
* Update: Woo loop content.
* Update: admin select2.

= Version 1.6.3 | 4th October 2018 =
* Update: Woo loop content template.

= Version 1.6.2 | 24th September 2018 =
* Update: shortcode css issue.
* Update: pot file issue.

= Version 1.6.1 | 21th September 2018 =
* Update: Elementor shortcode css issue.
* Update: Gutenberg 3.9 css
* Fix: Notice in video post.

= Version 1.6.0 | 14th September 2018 =
* Update: Gutenberg CSS
* Fix: Issue with Elementor Pro sticky.
* Update: Landing Template.
* Update: Make it possible to load subset fonts locally.

= Version 1.5.9 | 7th August 2018 =
* Fix: Dashboard CSS.
* Fix: Issue with shortcode button in widgets.
* Update: Gutenberg post format meta show hide.

= Version 1.5.8 | 3nd August 2018 =
* Fix: Issue radio selection.
* Update: Check to only load shortcode button on backend.

= Version 1.5.7 | 3nd August 2018 =
* Fix: Issue with flip box widget.
* Update: Few Gutenberg css tweeks.

= Version 1.5.6 | 2nd August 2018 =
* Update: Search Grid post type label.
* Update: Google Font json.
* Update: Admin getting started page.
* Fix: Quote sanitation for the flip box.

= Version 1.5.5 | 19th July 2018 =
* Update: Small JS update.
* Fix: ConvertPro Bug

= Version 1.5.4 | 18th July 2018 =
* Update: Better event support.
* Add: Page content width settings.
* Add: Gutenberg Support.

= Version 1.5.3 | 2nd July 2018 =
* Update: Fix lazy load in carousel.
* Update: Fix thumbnail slider thumbnails offscreen.
* Add: Woo store notice support.
* Add: option to set max items for post carousel.

= Version 1.5.2 | 26th June 2018 =
* Update: Accordion start all closed option.
* Update: Add initial Yoast BC title support.
* Fix: some servers default layout didn't want to be set for the portfolio posts.

= Version 1.5.1 | 22nd June 2018 =
* Update: Product image, better load and firefox issue fixed
* Update: Add Elementor Support.
* Update: Lazy Load functions, fix issue with srcset.
* Update: WPML config for attachment id in string translation.

= Version 1.5.0 | 4th June 2018 =
* Update: Page comment option.

= Version 1.4.9 | 30th May 2018 =
* Update: WC files for 3.4.1
* Add: option to auto download Google fonts and load locally.

= Version 1.4.8 | 22nd May 2018 =
* Fix: language issue with product search.

= Version 1.4.7 | 18th May 2018 =
* Fix: Rating off if they are globally off in Woocommerce settings.
* Fix: Mobile menu showing on both sides bug.
* Fix: Image size issue on single posts.
* Fix: Pagebuilder padding on posts with pagetitle showing.
* Add: Option for privacy policy checkbox in contact form.
* Add: Option for privacy policy checkbox in testimonial form.
* Add: option for optional name and subject in contact form.
* Add: option for show_required in contact form.
* Update: woocommerce files, support for 3.4.0

= Version 1.4.6 | 2nd May 2018 =
* Fix: Issue with polylang not picking up typed text to translate.
* Fix: Small issue with iso filter and sliders getting there height reset.
* Fix: Issue with error if select box cleared for sticky header.

= Version 1.4.5 | 26th April 2018 =
* Add: Support for link none in image carousel gallery.
* Fix: Issue with single post header default.
* Fix: css bug with select and IE

= Version 1.4.4 | 11th April 2018 =
* Update: Option to place image below header in single post.
* Update: Option for inherit ratio in home portfolio.
* Fix: portfolio default layout setting.
* Update: Image widget to better handle size and shapes.

= Version 1.4.3 | 19th March 2018 =
* Update: Some new actions for better intergartion.
* Update: Add inherit from image ratio for portfolio.
* Update: Add opiton to softcrop post images
* Update: Add "change" for image widget to trigger update.

= Version 1.4.2 | 9th March 2018 =
* Update: Sticky Header.
* Update: Testimonial form not showing response in pagebuilder.
* Update: contact form not showing response in pagebuilder.

= Version 1.4.1 | 26th February 2018 =
* Update: Fix carousel widget issue.
* Update: Fix sticky header issue.
* Update: Fix php notice.

= Version 1.4.0 | 22nd February 2018 =
* Update: Fix post shortcode issue.
* UPdate: Fix archive sidebar setting.
* Update: Fix for two login boxes on a page.

= Version 1.3.9 | 20th February 2018 =
* Update: Mobile header link options for account.
* Update: Woo Templates.

= Version 1.3.8 | 16th February 2018 =
* Fix: Issue with pagebuilder

= Version 1.3.7 | 15th February 2018 =
* Update: Sticky Header update.
* Add: filter for post background header image.
* Add: Breadcrumb above option.
* Add: Title Tag options.
* Add: Breadcrumb color options.
* Add: Screen size column options for carousel.
* Add: split to product layout options.
* Fix: Issue with Image carousel on larger screens.
* Fix: spacing of carousel.
* Fix: Shop title color.
* Fix: Mobile Menu colors.

= Version 1.3.6 | 5th February 2018 =
* Update: better filter plugin support.
* Update: Sticky header issues.

= Version 1.3.5 | 26th January 2018 =
* Fix: Filtered archive title
* Fix: breadcrumb issue.

= Version 1.3.4 | 23rd January 2018 =
* Updates: for Woo 3.3.
* Add: some support for Events manager

= Version 1.3.3 | 15th January 2018 =
* Fix: Issue home page blog image size.
* Add: custom tab class.
* Fix: issue with double login modal.

= Version 1.3.2 | 29th December 2017 =
* Fix: Issue with post loop not showing date.
* Fix: Issue with infinite scroll on safari
* Fix: Issue with vimeo shortcode.

= Version 1.3.1 | 18th December 2017 =
* Add: Option for topbar widget area on mobile.
* Update: IT lang
* Update: archive title for better polylang support.
* Fix: issue with appear js.
* Fix: issue with split content link target.
* Fix: issue with latest posts image size.
* Fix: issue with sharing not showing on home page.
* Fix: issue with php 7.2
* Fix: image menu shortcode issue.

= Version 1.3.0 | 1st November 2017 =
* Fix: Sidebar default issue.
* Fix: padding in getting started.
* Fix: Select2 multi styling.
* Add: Text transform to menu settings.
* Fix: Mosaic portfolio issue.
* Update: lightbox css.
* Update: css for conflict issue with testimonial carousel.

= Version 1.2.9 | 23th October 2017 =
* Add: Two new snippets
* Update: Allow logo tagline without title.
* Update: add filter for page/post title tag.
* Update: Image processing.
* Fix: Small issue with gallery slider.
* Update: Icons to use woff2
* Fix: Css for woo warning.
* Fix: Recommended typo.

= Version 1.2.8 | 11th October 2017 =
* Fix: Mobile cart ajax issue.
* Update: local scroll.

= Version 1.2.7 | 11th October 2017 =
* Update: Ready for woo 3.2
* Update: Gallery widget, autoplay.
* Update: Option for login to be link not popup.
* Update: Woo Account pages for better title support.

= Version 1.2.6 | 3rd October 2017 =
* Fix: Categories not showing in archives.
* Fix: Home Portfolio Title
* Fix: Issue with home portfolio if type is selected.

= Version 1.2.5 | 20th September 2017 =
* Add: Better Support for Event Organizer plugin.
* Add: Better Support for Seriously Simple Podcasting plugin.
* Add: Archive Description to post archives.
* Fix: Local Scroll Issue.
* Add: Cookless options to youtube shortcode.
* Add: Align options to image widget.
* Add: Tab style options to tab widget.
* Update: Sidebar padding with pagebuilder.
* Add: support for logo extras menu extras.

= Version 1.2.4 | 23th August 2017 =
* Add: New Custom Carousel Widget.
* Add: New Client Carousel Snippet.
* Add: Action hooks for page header.
* Update: CMB.
* Update: Included Kadence Slider version
* Update: Testimonial Carousel options.
* Update: Ascend Title for better bbpress support.
* Update: Defaults for height with image carousel and different ratio sliders in portfolio posts.
* Fix: Issue with custom carousel shortcode.
* Fix: Issue with product sidebar.
* Fix: Footer meta issue.

= Version 1.2.3 | 7th August 2017 =
* Fix: Math issue with contact form. 
* Fix: issue with search in topbar and header.
* Fix: issue with showing "cart" label in header.

= Version 1.2.2 | 26th July 2017 =
* Add: Animation options for page builder. 
* Add: Shape and boxshadow features to Image widget.
* Add: 8 new layout Snippets
* Add: Minimal Icon Font option.
* Update: Contact has "light" style version.
* Update: Call to action widget with new changes.

= Version 1.2.1 | 10th July 2017 =
* Update: remove .ds_store

= Version 1.2.0 | 7th July 2017 =
* Update: Add tabs and accordion widget.
* Update: Gallery grid to link to post.
* Update: Infinite scroll.
* Update: CMB

= Version 1.1.9 | 15th June 2017 =
* Update: Ready for woo 3.1
* Update: Post mosaic gallery captions.
* Fix: Large mosaic post layout issues.
* Fix: Variation styling issue.
* Fix: Admin orders styling issue.
* Fix: Secondary Nav styling issue.

= Version 1.1.8 | 7th June 2017 =
* Fix: Topbar search issue.
* Fix: Product Sidebar Side issue.
* Update: Contact form, remove sessions.
* Fix: Shrink logo issue in IE

= Version 1.1.7 | 17th May 2017 =
* Update: flexbox js.
* Update: Split content text align.
* Update: schema.
* Fix: Issue with portfolio random.

= Version 1.1.6 | 3rd May 2017 =
* Update: Admin css.
* Update: Better support Kadence Galleries.
* Fix: Lightbox Issue.
* Fix: IE css.
* Add: Google Tag manager output.

= Version 1.1.5 | 20th April 2017 =
* Fix: woo notice.
* Fix: Shortcode issue.

= Version 1.1.4 | 20th April 2017 =
* Fix: Issue with pagebuilder update and separators.
* Fix: Issue portfolio grid columns on home page.
* Fix: Gallery captions issue.

= Version 1.1.3 | 12th April 2017 =
* Fix: WC notice.
* Fix: Ajax select2 variation update.
* Fix: Product zoom init.
* Update: Schema.

= Version 1.1.2 | 7th April 2017 =
* Fix: WC notice.
* Update: Language files.
* Fix: Image processing issue.

= Version 1.1.1 | 6th April 2017 =
* Fix: Small variations issue.
* Fix: Issue with thankyou page 3.0

= Version 1.1.0 | 6th April 2017 =
* Fix: issue with mobile icon menu
* Fix: issue with featured products WC 3.0
* Fix: Issue with portfolio sidebar.
* Fix: Issue with select2 on front end.

= Version 1.0.9 | 3rd April 2017 =
* Update: WC 3.0
* Update: Issue with top spacing on mobile.
* Update: Clear Content floats
* Update: Select2 v4 css.
* Add: Transparent header text hover color.

= Version 1.0.8 | 20th March 2017 =
* Update: Breadcrumbs
* Add: Support for primary term from yoast.
* Fix: Icon menu issue.

= Version 1.0.7 | 13th March 2017 =
* Fix: Smoothscroll Issue.
* Fix: Search Sidebar Issue.

= Version 1.0.6 | 8th March 2017 =
* Fix: Select2 Issues
* Fix: Issue with gallery and really small images.
* Fix: Issue with footer background when image.

= Version 1.0.5 | 4th March 2017 =
* Add: Second widget area to header extras.
* Add: Hide label option to menu.
* Add: Mobile Top icon bar.
* Fix: Issue with single column blog carousels.
* Fix: Issue with mobile transparent header logo switch.
* Fix: Issue with home product carousel columns.
* Fix: Issue with home mobile page title height.

= Version 1.0.4 | 24th February 2017 =
* Update: js masonry to work better with full width panels.

= Version 1.0.3 | 24th February 2017 =
* Update: Column widths 33.33%
* Fix: Filter showing on home when off.

= Version 1.0.2 | 23th February 2017 =
* Update: Add woomessage to every page for modal login.
* Update: Add default option for page titles.
* Update: If you set transparent to true in the page then it will have a transparent header even if no page title.
* Update: RTL css.
* Fix: Login missing for topbar account.
* Fix: Edge Issues with transparent background (Edge is the worst).

= Version 1.0.1 | 22th February 2017 =
* Fix: Firefox bug.
* Update: Couple Woo files in prep for 2.7
* Update: Options title area for better flow.

= Version 1.0.0 | 17th February 2017 =
* initial
