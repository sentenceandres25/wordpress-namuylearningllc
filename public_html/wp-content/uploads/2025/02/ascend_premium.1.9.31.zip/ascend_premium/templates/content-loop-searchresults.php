  <?php 
if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}
global $post, $ascend, $ascend_has_sidebar;
if($ascend_has_sidebar) {
	$image_width = 360;
	$image_height = 240;
} else {
	$image_width = 420;
	$image_height = 280;
}

if(isset($ascend['postexcerpt_hard_crop']) && $ascend['postexcerpt_hard_crop'] == 1) {
    $image_crop = true;
} else {
    $image_height = null;
    $image_crop = false;
}
    ?>
    <article id="post-<?php the_ID(); ?>" class="search_results_item postclass kt_item_fade_in grid_item">
        <?php 
        if (has_post_thumbnail( $post->ID ) ) {
	        $img = ascend_get_image($image_width, $image_height, $image_crop, null, null, null, true);
	        $img['schema'] = true;
        ?>
        	<a href="<?php the_permalink() ?>" class="imghoverclass img-margin-center">
	            <div class="kt-intrinsic" style="padding-bottom:<?php echo ($img['height']/$img['width']) * 100;?>%;">
	                <?php 
	                echo ascend_get_image_markup( $img );
	               ?>
	            </div> 
	        </a>
        <?php }
        ?>
        <div class="postcontent">
          	<header>
	            <a href="<?php the_permalink() ?>">
	            	<h5 class="entry-title"><?php the_title(); ?></h5>
	            </a>
	            <span class="kt_search_post_type">
	            	<?php
	            	$post_object = get_post_type_object( get_post_type( $post->ID ) );
	              	echo $post_object->labels->singular_name;
	              	?>
	            </span>
          	</header>
        	<div class="entry-content">
	            <?php 
	            the_excerpt();
	            ?>
        	</div>
      	</div><!-- search content -->
	</article> 