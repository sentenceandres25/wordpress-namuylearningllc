<?php 

global $post, $ascend, $ascend_has_sidebar, $ascend_grid_columns, $kt_grid_carousel;
    if($ascend_has_sidebar) {
        if(!empty($ascend_grid_columns)) {
            if($ascend_grid_columns == '3') {
                $image_width = 420;
                $image_height = 280;
            } else if($ascend_grid_columns == '2') {
                $image_width = 660;
                $image_height = 440;
            } else {
                $image_width = 360;
                $image_height = 240;
            }
        } else {
            $image_width = 360;
            $image_height = 240;
        }
    } else {
        if(!empty($ascend_grid_columns)) {
            if($ascend_grid_columns == '3') {
                $image_width = 480;
                $image_height = 320;

            } else if($ascend_grid_columns == '2') {
                $image_width = 660;
                $image_height = 440;
            } else {
                $image_width = 360;
                $image_height = 240;
            }
        } else {
            $image_width = 360;
            $image_height = 240;
        }
    }

    $image_width = apply_filters('kt_post_grid_image_width', $image_width);
    $image_height = apply_filters('kt_post_grid_image_height', $image_height);
    if(isset($kt_grid_carousel) && $kt_grid_carousel != true) {
	    if(isset($ascend['postexcerpt_hard_crop']) && $ascend['postexcerpt_hard_crop'] == 1) {
	        $image_crop = true;
	    } else {
	        $image_height = null;
	        $image_crop = false;
	    }
	    $lazy = true;
	} else {
		$image_crop = true;
		$lazy = false;
	}
    ?>
    <article id="post-<?php the_ID(); ?>" class="blog_item blog_photo_item kt_item_fade_in grid_item">
        <div class="imghoverclass img-margin-center blog-grid-photo">
        <?php 
        $img = ascend_get_image($image_width, $image_height, $image_crop, null, null, null, true);
        $img['schema'] = true;
        $img['lazy'] = $lazy;
        ?>
            <div class="kt-intrinsic" style="padding-bottom:<?php echo ($img['height']/$img['width']) * 100;?>%;">
                <?php 
                 echo ascend_get_image_markup( $img );
               ?>
            </div> 
        </div>
        <div class="photo-postcontent">
            <div class="photo-post-bg">
            </div>
            <div class="photo-postcontent-inner">
                <?php 
                /**
                *
                */
                do_action( 'kadence_post_photo_grid_excerpt_before_header' );
                ?>
                <header>
                    <?php 
                    /**
                    * @hooked ascend_post_grid_excerpt_header_title - 10
                    */
                    do_action( 'kadence_post_photo_grid_excerpt_header' );
                    ?>
                </header>
                <div class="kt-post-photo-added-content">
                    <?php 
                    /**
                    * @hooked ascend_post_header_meta_categories - 20
                    */
                    do_action( 'kadence_post_photo_grid_excerpt_after_header' );
                    ?>
                </div>
            </div>
            <a href="<?php the_permalink() ?>" class="photo-post-link">
            </a>
        </div><!-- Text size -->
        <?php 
        /**
        * 
        */
        do_action( 'kadence_post_grid_excerpt_after_footer' );
        ?>
    </article> <!-- Blog Item -->